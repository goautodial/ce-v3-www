<!-- jerico james milo -->
<?php
############################################################################################
####  Name:             login.php                                                       ####
####  Type: 		       ci views 																   ####
####  Version:          3.0                                                             ####
####  Copyright:        GOAutoDial Inc. - Jerico James Milo <james@goautodial.com>      #### 
####  License:          AGPLv2                                                          ####
############################################################################################
?>

<html>
<head>
<title>GoAutoDial - Empowering the Next Generation Contact Centers</title>
<meta http-equiv="Content-Type"sdf content="text/html; charset=utf-8">
<!--[if gte IE 9]>
  <style type="text/css">
    .gradient {
       filter: none;
    }
  </style>
<![endif]-->
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="shortcut icon" href="../img/gologoico.ico" />
<script type="text/javascript" src="jquery-1.2.6.min.js"></script>

</head>
<body class="bodybgback" id="element">
	<!--<div class="bodyheader" id="newElement"> &nbsp;&nbsp;
		 <span style="margin-left: 24%;">
		 	<img src="smalllogo.png" style="position: absolute;" style="margin-right: 100%;" height="22px">
		 </span>
		 <span style="margin-left: 45%; font-size: 13px; margin-top: 4px; position: absolute;">
			<a href="https://<?=$_SERVER['SERVER_NAME'];?>/login/" style="color: white; text-decoration: none;" title="Login">
				<b>Login</b>
			</a>
		 </span>
	</div>-->
<br><br><br><br>
<center>
	<table align="center" border="0" cellpadding="0" cellspacing="0">
		<tbody>
		  <tr>
		    <td align="center"><img width="150px;" src="goautodial_logo.png"></td>
		  </tr>
		  <tr>
		    <td align="center">&nbsp;&nbsp;</td>
		  </tr>
		  <tr>
		    <td align="center">Looks like you're using Microsoft Internet Explorer. This site works best with Mozilla Firefox or Google Chrome.</td>
		  </tr>
		  <tr>
		    <td align="center">
		      Download them here: <a href="http://www.mozilla.org/en-US/firefox/new/" target="_blank" title="Firefox">Firefox</a>
		      and <a href="https://www.google.com/intl/en/chrome/browser/" target="_blank" title="Chrome">Chrome</a>
		    </td>
		  </tr>
		</tbody>
	</table>
</center>
</body>
</html>
